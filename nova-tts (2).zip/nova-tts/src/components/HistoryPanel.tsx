import { motion, AnimatePresence } from 'framer-motion'
import { Star, Trash2, History as HistoryIcon, CornerDownLeft } from 'lucide-react'
import type { HistoryEntry } from '../types'

interface HistoryPanelProps {
  history: HistoryEntry[]
  onLoad: (entry: HistoryEntry) => void
  onToggleFavorite: (id: string) => void
  onDelete: (id: string) => void
}

export default function HistoryPanel({ history, onLoad, onToggleFavorite, onDelete }: HistoryPanelProps) {
  if (history.length === 0) {
    return (
      <div className="flex flex-col items-center gap-2 py-8 text-center text-white/30">
        <HistoryIcon className="h-6 w-6" strokeWidth={1.5} />
        <p className="font-mono text-[11px] tracking-wider">NO SAVED ENTRIES YET</p>
      </div>
    )
  }

  const sorted = [...history].sort((a, b) => {
    if (a.favorite !== b.favorite) return a.favorite ? -1 : 1
    return b.timestamp - a.timestamp
  })

  return (
    <div className="max-h-72 space-y-2 overflow-y-auto pr-1">
      <AnimatePresence initial={false}>
        {sorted.map((entry) => (
          <motion.div
            key={entry.id}
            layout
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 8 }}
            className="group flex items-start gap-2 rounded-lg border border-white/5 bg-white/[0.02] p-3 transition hover:border-cyan-glow/30"
          >
            <button
              onClick={() => onToggleFavorite(entry.id)}
              className="mt-0.5 shrink-0"
              aria-label="Toggle favorite"
              title="Toggle favorite"
            >
              <Star
                className={`h-4 w-4 transition ${
                  entry.favorite ? 'fill-cyan-glow text-cyan-glow' : 'text-white/25 hover:text-cyan-glow/60'
                }`}
              />
            </button>

            <div className="min-w-0 flex-1">
              <p className="truncate text-sm text-white/80">{entry.text}</p>
              <p className="mt-0.5 font-mono text-[10px] text-white/30">
                {new Date(entry.timestamp).toLocaleString()}
                {entry.voiceName ? ` · ${entry.voiceName}` : ''}
              </p>
            </div>

            <div className="flex shrink-0 items-center gap-1 opacity-0 transition group-hover:opacity-100">
              <button
                onClick={() => onLoad(entry)}
                className="rounded p-1.5 text-white/50 hover:bg-white/5 hover:text-cyan-glow"
                aria-label="Load into editor"
                title="Load into editor"
              >
                <CornerDownLeft className="h-3.5 w-3.5" />
              </button>
              <button
                onClick={() => onDelete(entry.id)}
                className="rounded p-1.5 text-white/50 hover:bg-white/5 hover:text-red-300"
                aria-label="Delete entry"
                title="Delete entry"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  )
}
