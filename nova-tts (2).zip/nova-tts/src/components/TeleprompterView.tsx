import { useMemo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import type { SpeechBoundary } from '../hooks/useSpeech'
import type { SpeechStatus } from '../types'

interface TeleprompterViewProps {
  sentences: string[]
  currentSentenceIndex: number
  boundary: SpeechBoundary | null
  status: SpeechStatus
}

interface Token {
  word: string
  start: number
  end: number
}

function tokenize(text: string): Token[] {
  const tokens: Token[] = []
  const re = /\S+/g
  let match: RegExpExecArray | null
  while ((match = re.exec(text)) !== null) {
    tokens.push({ word: match[0], start: match.index, end: match.index + match[0].length })
  }
  return tokens
}

function HighlightedSentence({ text, boundary }: { text: string; boundary: SpeechBoundary | null }) {
  const tokens = useMemo(() => tokenize(text), [text])

  const activeIndex = useMemo(() => {
    if (!boundary) return -1
    const target = boundary.charIndex
    let found = tokens.findIndex((t) => target >= t.start && target < t.end)
    if (found === -1) found = tokens.findIndex((t) => t.start >= target)
    return found
  }, [boundary, tokens])

  return (
    <>
      {tokens.map((t, i) => {
        const isActive = i === activeIndex
        const isPast = activeIndex !== -1 && i < activeIndex
        return (
          <span key={i} className="mr-[0.32em] inline-block">
            {isActive ? (
              <motion.span
                layout
                className="relative rounded px-1 py-0.5 text-cyan-glow"
                style={{
                  background: 'rgba(0,229,255,0.16)',
                  boxShadow: '0 0 14px rgba(0,229,255,0.4)',
                }}
                transition={{ duration: 0.15 }}
              >
                {t.word}
              </motion.span>
            ) : (
              <span className={isPast ? 'text-white/40' : 'text-white/90'}>{t.word}</span>
            )}
          </span>
        )
      })}
    </>
  )
}

export default function TeleprompterView({
  sentences,
  currentSentenceIndex,
  boundary,
  status,
}: TeleprompterViewProps) {
  if (!sentences.length || currentSentenceIndex < 0) return null

  const prev = sentences[currentSentenceIndex - 1]
  const current = sentences[currentSentenceIndex]
  const next = sentences[currentSentenceIndex + 1]

  if (!current) return null

  return (
    <div className="overflow-hidden rounded-xl border border-white/5 bg-black/20 px-6 py-8 sm:px-10 sm:py-10">
      <div className="mx-auto flex max-w-2xl flex-col items-center gap-4 text-center">
        {/* Previous sentence, fading away above */}
        <div className="h-6 w-full overflow-hidden sm:h-7">
          <AnimatePresence mode="popLayout">
            {prev && (
              <motion.p
                key={`prev-${currentSentenceIndex}`}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 0.35, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.35, ease: 'easeOut' }}
                className="truncate font-body text-sm text-white/40 sm:text-base"
              >
                {prev}
              </motion.p>
            )}
          </AnimatePresence>
        </div>

        {/* Current sentence, spotlighted */}
        <div className="min-h-[3.5rem] w-full sm:min-h-[4.5rem]">
          <AnimatePresence mode="wait">
            <motion.p
              key={`current-${currentSentenceIndex}`}
              initial={{ opacity: 0, y: 16, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.35, ease: 'easeOut' }}
              className="font-body text-xl leading-relaxed sm:text-2xl"
            >
              <HighlightedSentence text={current} boundary={boundary} />
            </motion.p>
          </AnimatePresence>
        </div>

        {/* Next sentence, faint preview below */}
        <div className="h-6 w-full overflow-hidden sm:h-7">
          <AnimatePresence mode="popLayout">
            {next && (
              <motion.p
                key={`next-${currentSentenceIndex}`}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 0.25, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.35, ease: 'easeOut' }}
                className="truncate font-body text-sm text-white/30 sm:text-base"
              >
                {next}
              </motion.p>
            )}
          </AnimatePresence>
        </div>

        {status === 'paused' && (
          <p className="mt-1 font-mono text-[10px] tracking-widest text-white/30">— PAUSED —</p>
        )}
      </div>
    </div>
  )
}
