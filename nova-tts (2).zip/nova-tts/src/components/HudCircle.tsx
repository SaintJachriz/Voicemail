import { motion } from 'framer-motion'
import { Mic } from 'lucide-react'
import type { SpeechStatus } from '../types'

interface HudCircleProps {
  status: SpeechStatus
  level: number
}

export default function HudCircle({ status, level }: HudCircleProps) {
  const active = status === 'speaking'

  return (
    <div className="relative mx-auto flex h-56 w-56 items-center justify-center sm:h-64 sm:w-64">
      {/* Outer rotating ring, dashed */}
      <div
        className="absolute inset-0 rounded-full border border-dashed border-cyan-glow/30 animate-spin-slow"
        style={{ borderWidth: 1 }}
      />
      {/* Middle rotating ring, reverse */}
      <div className="absolute inset-6 rounded-full border border-blue-glow/40 animate-spin-reverse" />
      {/* Segmented tick ring */}
      <svg className="absolute inset-0 h-full w-full animate-spin-slow" viewBox="0 0 200 200">
        {Array.from({ length: 36 }).map((_, i) => {
          const angle = (i / 36) * 360
          return (
            <line
              key={i}
              x1={100}
              y1={6}
              x2={100}
              y2={14}
              stroke="rgba(0,229,255,0.55)"
              strokeWidth={i % 3 === 0 ? 2 : 1}
              transform={`rotate(${angle} 100 100)`}
            />
          )
        })}
      </svg>

      {/* Pulsing glow ring reacting to speech level */}
      <motion.div
        className="absolute inset-10 rounded-full bg-cyan-glow/10"
        animate={{
          scale: active ? [1, 1 + level * 0.25, 1] : 1,
          opacity: active ? [0.4, 0.7, 0.4] : 0.25,
        }}
        transition={{ duration: 0.4, repeat: active ? Infinity : 0 }}
        style={{ filter: 'blur(10px)' }}
      />

      {/* Core glass disc */}
      <div className="relative flex h-32 w-32 items-center justify-center rounded-full glass-panel shadow-neon-cyan sm:h-36 sm:w-36">
        <motion.div
          animate={
            active
              ? { scale: [1, 1.12, 1] }
              : status === 'paused'
              ? { scale: 1 }
              : { scale: [1, 1.03, 1] }
          }
          transition={{ duration: active ? 0.6 : 3, repeat: Infinity, ease: 'easeInOut' }}
          className="flex h-full w-full items-center justify-center rounded-full"
        >
          <Mic
            className={`h-10 w-10 sm:h-12 sm:w-12 ${
              active ? 'text-cyan-glow animate-pulse-glow' : 'text-cyan-glow/70'
            }`}
            strokeWidth={1.5}
          />
        </motion.div>
      </div>

      {/* Orbiting node */}
      <motion.div
        className="absolute inset-0"
        animate={{ rotate: 360 }}
        transition={{ duration: 6, repeat: Infinity, ease: 'linear' }}
      >
        <div className="absolute left-1/2 top-0 h-2.5 w-2.5 -translate-x-1/2 rounded-full bg-white shadow-neon-cyan" />
      </motion.div>
    </div>
  )
}
