import { useCallback, useEffect, useRef, useState } from 'react'
import type { ChangeEvent, DragEvent } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Copy, Trash2, UploadCloud, Check, FileUp, Loader2 } from 'lucide-react'
import { parseDocumentFile, ACCEPTED_MIME_HINT, UnsupportedFileError } from '../utils/parseDocument'

interface TextEditorProps {
  value: string
  onChange: (value: string) => void
  disabled?: boolean
}

const TYPING_PHRASES = [
  'Type or paste anything to hear it spoken aloud...',
  'Or drop a .txt, .md, .docx, or .pdf file here...',
  'Unlimited length. No character limit.',
]

export default function TextEditor({ value, onChange, disabled }: TextEditorProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [copied, setCopied] = useState(false)
  const [isParsing, setIsParsing] = useState(false)
  const [parseError, setParseError] = useState<string | null>(null)
  const [placeholderIdx, setPlaceholderIdx] = useState(0)
  const [displayedPlaceholder, setDisplayedPlaceholder] = useState('')
  const dragCounter = useRef(0)
  const fileInputRef = useRef<HTMLInputElement | null>(null)

  // Typing animation for the placeholder, only while textarea is empty
  useEffect(() => {
    if (value) return
    let charIndex = 0
    let cancelled = false
    const currentPhrase = TYPING_PHRASES[placeholderIdx % TYPING_PHRASES.length]

    const typeNext = () => {
      if (cancelled) return
      if (charIndex <= currentPhrase.length) {
        setDisplayedPlaceholder(currentPhrase.slice(0, charIndex))
        charIndex++
        window.setTimeout(typeNext, 45)
      } else {
        window.setTimeout(() => {
          if (!cancelled) setPlaceholderIdx((i) => i + 1)
        }, 1800)
      }
    }
    typeNext()
    return () => {
      cancelled = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [placeholderIdx, value])

  const handleCopy = useCallback(async () => {
    if (!value) return
    try {
      await navigator.clipboard.writeText(value)
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1600)
    } catch {
      // Clipboard API unavailable — silently ignore.
    }
  }, [value])

  const handleClear = useCallback(() => onChange(''), [onChange])

  const loadFile = useCallback(
    async (file: File) => {
      setParseError(null)
      setIsParsing(true)
      try {
        const extracted = await parseDocumentFile(file)
        onChange(value ? `${value}\n\n${extracted}` : extracted)
      } catch (err) {
        if (err instanceof UnsupportedFileError) {
          setParseError(err.message)
        } else {
          setParseError(`Couldn't read "${file.name}". The file may be corrupted or scanned as images only.`)
        }
      } finally {
        setIsParsing(false)
      }
    },
    [onChange, value],
  )

  const handleDrop = useCallback(
    (e: DragEvent<HTMLDivElement>) => {
      e.preventDefault()
      setIsDragging(false)
      dragCounter.current = 0
      const file = e.dataTransfer.files?.[0]
      if (file) loadFile(file)
    },
    [loadFile],
  )

  const handleDragEnter = useCallback((e: DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    dragCounter.current += 1
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    dragCounter.current -= 1
    if (dragCounter.current <= 0) setIsDragging(false)
  }, [])

  const handleBrowseClick = useCallback(() => fileInputRef.current?.click(), [])

  const handleFileInputChange = useCallback(
    (e: ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0]
      if (file) loadFile(file)
      e.target.value = '' // allow re-selecting the same file later
    },
    [loadFile],
  )

  return (
    <div
      className="relative"
      onDrop={handleDrop}
      onDragOver={(e) => e.preventDefault()}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
    >
      <div className="relative rounded-2xl glass-panel shadow-neon-soft">
        {/* Corner HUD brackets */}
        <span className="pointer-events-none absolute -left-1 -top-1 h-5 w-5 border-l-2 border-t-2 border-cyan-glow/60 rounded-tl-lg" />
        <span className="pointer-events-none absolute -right-1 -top-1 h-5 w-5 border-r-2 border-t-2 border-cyan-glow/60 rounded-tr-lg" />
        <span className="pointer-events-none absolute -left-1 -bottom-1 h-5 w-5 border-l-2 border-b-2 border-cyan-glow/60 rounded-bl-lg" />
        <span className="pointer-events-none absolute -right-1 -bottom-1 h-5 w-5 border-r-2 border-b-2 border-cyan-glow/60 rounded-br-lg" />

        <textarea
          value={value}
          disabled={disabled || isParsing}
          onChange={(e) => onChange(e.target.value)}
          placeholder={displayedPlaceholder || ' '}
          rows={10}
          className="w-full resize-y rounded-2xl bg-transparent p-5 font-body text-base leading-relaxed text-white/90 placeholder:text-white/25 focus:outline-none disabled:opacity-50 sm:p-6 sm:text-lg"
          aria-label="Text to speak"
        />

        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-white/5 px-5 pb-4 pt-3 sm:px-6">
          <span className="font-mono text-[11px] tracking-wider text-white/40">
            {value.length.toLocaleString()} characters &middot; no limit
          </span>
          <div className="flex flex-wrap items-center gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept={ACCEPTED_MIME_HINT}
              className="hidden"
              onChange={handleFileInputChange}
            />
            <button
              onClick={handleBrowseClick}
              disabled={isParsing}
              className="flex items-center gap-1.5 rounded-lg border border-white/10 px-3 py-1.5 font-mono text-[11px] text-white/60 transition hover:border-cyan-glow/50 hover:text-cyan-glow disabled:opacity-40"
              aria-label="Upload document"
              title="Upload .txt, .md, .docx, or .pdf"
            >
              {isParsing ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <FileUp className="h-3.5 w-3.5" />
              )}
              {isParsing ? 'Reading…' : 'Upload'}
            </button>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 rounded-lg border border-white/10 px-3 py-1.5 font-mono text-[11px] text-white/60 transition hover:border-cyan-glow/50 hover:text-cyan-glow"
              aria-label="Copy text"
              title="Copy (Ctrl/Cmd + Shift + C)"
            >
              {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              {copied ? 'Copied' : 'Copy'}
            </button>
            <button
              onClick={handleClear}
              className="flex items-center gap-1.5 rounded-lg border border-white/10 px-3 py-1.5 font-mono text-[11px] text-white/60 transition hover:border-red-400/50 hover:text-red-300"
              aria-label="Clear text"
              title="Clear (Ctrl/Cmd + Backspace)"
            >
              <Trash2 className="h-3.5 w-3.5" />
              Clear
            </button>
          </div>
        </div>

        {parseError && (
          <div className="mx-5 mb-4 rounded-lg border border-red-400/30 bg-red-400/5 px-3 py-2 font-mono text-[11px] text-red-300 sm:mx-6">
            {parseError}
          </div>
        )}
      </div>

      <AnimatePresence>
        {isDragging && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-10 flex items-center justify-center rounded-2xl border-2 border-dashed border-cyan-glow bg-void-900/80 backdrop-blur-sm"
          >
            <div className="flex flex-col items-center gap-2 text-cyan-glow">
              <UploadCloud className="h-8 w-8 animate-float" />
              <span className="font-mono text-sm tracking-wider">DROP TO LOAD (.TXT · .MD · .DOCX · .PDF)</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
