import type { LucideIcon } from 'lucide-react'

interface ControlSliderProps {
  label: string
  icon: LucideIcon
  value: number
  min: number
  max: number
  step: number
  onChange: (value: number) => void
  formatValue?: (value: number) => string
}

export default function ControlSlider({
  label,
  icon: Icon,
  value,
  min,
  max,
  step,
  onChange,
  formatValue,
}: ControlSliderProps) {
  const percent = ((value - min) / (max - min)) * 100
  const display = formatValue ? formatValue(value) : value.toFixed(2)

  return (
    <div>
      <div className="mb-2 flex items-center justify-between font-mono text-[11px] tracking-wider text-white/60">
        <span className="flex items-center gap-1.5">
          <Icon className="h-3.5 w-3.5 text-cyan-glow/70" strokeWidth={1.5} />
          {label}
        </span>
        <span className="text-cyan-glow">{display}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        style={{ ['--fill' as string]: `${percent}%` }}
        aria-label={label}
      />
    </div>
  )
}
