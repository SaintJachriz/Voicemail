import { useMemo } from 'react'
import { motion } from 'framer-motion'
import type { SpeechStatus } from '../types'

interface EqualizerProps {
  status: SpeechStatus
  level: number
  bars?: number
}

export default function Equalizer({ status, level, bars = 40 }: EqualizerProps) {
  const active = status === 'speaking'
  const seeds = useMemo(() => Array.from({ length: bars }, () => Math.random()), [bars])

  return (
    <div className="flex h-14 w-full items-end justify-center gap-[3px] sm:h-16">
      {seeds.map((seed, i) => {
        const base = 0.1 + seed * 0.25
        const target = active ? Math.min(1, base + level * (0.4 + seed * 0.6)) : base
        return (
          <motion.div
            key={i}
            className="w-full max-w-[5px] rounded-full bg-gradient-to-t from-blue-glow to-cyan-glow"
            animate={{ height: `${target * 100}%`, opacity: active ? 1 : 0.35 }}
            transition={{ duration: 0.12, ease: 'easeOut' }}
            style={{ boxShadow: active ? '0 0 6px rgba(0,229,255,0.6)' : 'none' }}
          />
        )
      })}
    </div>
  )
}
