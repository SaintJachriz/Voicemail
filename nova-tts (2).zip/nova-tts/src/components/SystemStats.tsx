import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Cpu, MemoryStick, Wifi } from 'lucide-react'
import GlassPanel from './GlassPanel'

interface Stat {
  label: string
  value: number
  icon: typeof Cpu
}

function useFakeMetric(base: number, variance: number) {
  const [value, setValue] = useState(base)
  useEffect(() => {
    const id = setInterval(() => {
      setValue(() => {
        const next = base + (Math.random() - 0.5) * variance
        return Math.min(98, Math.max(4, Math.round(next)))
      })
    }, 1800)
    return () => clearInterval(id)
  }, [base, variance])
  return value
}

function StatBar({ label, value, icon: Icon }: Stat) {
  return (
    <div className="flex items-center gap-3">
      <Icon className="h-4 w-4 shrink-0 text-cyan-glow/80" strokeWidth={1.5} />
      <div className="flex-1">
        <div className="mb-1 flex justify-between font-mono text-[10px] tracking-wider text-white/50">
          <span>{label}</span>
          <span>{value}%</span>
        </div>
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/5">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-blue-glow to-cyan-glow"
            animate={{ width: `${value}%` }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          />
        </div>
      </div>
    </div>
  )
}

export default function SystemStats() {
  const cpu = useFakeMetric(42, 30)
  const mem = useFakeMetric(58, 20)
  const net = useFakeMetric(70, 25)

  return (
    <GlassPanel delay={0.3} className="p-4 sm:p-5">
      <p className="mb-3 font-mono text-[10px] tracking-[0.3em] text-white/40">SYSTEM DIAGNOSTICS</p>
      <div className="space-y-3">
        <StatBar label="CPU LOAD" value={cpu} icon={Cpu} />
        <StatBar label="MEMORY" value={mem} icon={MemoryStick} />
        <StatBar label="NETWORK" value={net} icon={Wifi} />
      </div>
    </GlassPanel>
  )
}
