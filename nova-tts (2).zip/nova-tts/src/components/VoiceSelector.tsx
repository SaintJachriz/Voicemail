import { ChevronDown } from 'lucide-react'

interface VoiceSelectorProps {
  voices: SpeechSynthesisVoice[]
  voiceURI: string | null
  onChange: (voiceURI: string) => void
}

export default function VoiceSelector({ voices, voiceURI, onChange }: VoiceSelectorProps) {
  return (
    <div>
      <label className="mb-2 flex items-center gap-1.5 font-mono text-[11px] tracking-wider text-white/60">
        VOICE
      </label>
      <div className="relative">
        <select
          value={voiceURI ?? ''}
          onChange={(e) => onChange(e.target.value)}
          className="w-full appearance-none rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2.5 pr-9 font-body text-sm text-white/90 outline-none transition focus:border-cyan-glow/60"
        >
          {voices.length === 0 && <option value="">Loading voices…</option>}
          {voices.map((v) => (
            <option key={v.voiceURI} value={v.voiceURI} className="bg-void-800 text-white">
              {v.name} ({v.lang})
            </option>
          ))}
        </select>
        <ChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-cyan-glow/60" />
      </div>
    </div>
  )
}
