import { motion } from 'framer-motion'
import { useClock } from '../hooks/useClock'
import type { SpeechStatus } from '../types'

export default function Header({ status }: { status: SpeechStatus }) {
  const { time, date } = useClock()

  const statusLabel =
    status === 'speaking' ? 'SPEAKING' : status === 'paused' ? 'PAUSED' : status === 'error' ? 'ERROR' : 'ONLINE'
  const statusColor =
    status === 'error' ? '#ff5c5c' : status === 'speaking' ? '#00e5ff' : '#2979ff'

  return (
    <header className="flex flex-col items-center gap-3 pb-6 pt-8 text-center sm:pt-10">
      <motion.h1
        initial={{ opacity: 0, y: -12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="font-display text-3xl font-black tracking-[0.15em] text-white text-neon sm:text-5xl"
      >
        NOVA
      </motion.h1>
      <p className="font-mono text-[11px] tracking-[0.4em] text-cyan-glow/70 sm:text-xs">
        AI VOICE CONSOLE
      </p>

      <div className="mt-2 flex flex-wrap items-center justify-center gap-3 font-mono text-[11px] sm:text-xs">
        <div className="flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5">
          <motion.span
            className="h-2 w-2 rounded-full"
            style={{ backgroundColor: statusColor, boxShadow: `0 0 8px ${statusColor}` }}
            animate={{ opacity: [1, 0.4, 1] }}
            transition={{ duration: 1.4, repeat: Infinity }}
          />
          <span style={{ color: statusColor }}>AI STATUS: {statusLabel}</span>
        </div>
        <div className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 text-white/70">
          {date}
        </div>
        <div className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 tabular-nums text-white/70">
          {time}
        </div>
      </div>
    </header>
  )
}
