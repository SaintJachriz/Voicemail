import type { ReactNode } from 'react'
import { motion } from 'framer-motion'
import { Play, Pause, Square, Star, Save } from 'lucide-react'
import type { SpeechStatus } from '../types'

interface TransportControlsProps {
  status: SpeechStatus
  disabled: boolean
  onPlay: () => void
  onPause: () => void
  onResume: () => void
  onStop: () => void
  onFavorite: () => void
  onSave: () => void
  isFavorite: boolean
}

function TransportButton({
  onClick,
  disabled,
  primary,
  children,
  label,
}: {
  onClick: () => void
  disabled?: boolean
  primary?: boolean
  children: ReactNode
  label: string
}) {
  return (
    <motion.button
      whileTap={{ scale: 0.94 }}
      onClick={onClick}
      disabled={disabled}
      aria-label={label}
      title={label}
      className={`flex items-center gap-2 rounded-xl px-4 py-3 font-mono text-xs font-semibold tracking-wider transition disabled:cursor-not-allowed disabled:opacity-30 sm:px-5 ${
        primary
          ? 'bg-gradient-to-r from-blue-glow to-cyan-glow text-void-950 shadow-neon-cyan'
          : 'border border-white/10 bg-white/[0.03] text-white/70 hover:border-cyan-glow/50 hover:text-cyan-glow'
      }`}
    >
      {children}
    </motion.button>
  )
}

export default function TransportControls({
  status,
  disabled,
  onPlay,
  onPause,
  onResume,
  onStop,
  onFavorite,
  onSave,
  isFavorite,
}: TransportControlsProps) {
  const speaking = status === 'speaking'
  const paused = status === 'paused'

  return (
    <div className="flex flex-wrap items-center gap-2.5 sm:gap-3">
      {paused ? (
        <TransportButton onClick={onResume} primary label="Resume (Space)">
          <Play className="h-4 w-4" fill="currentColor" /> RESUME
        </TransportButton>
      ) : (
        <TransportButton onClick={onPlay} disabled={disabled || speaking} primary label="Speak (Space)">
          <Play className="h-4 w-4" fill="currentColor" /> SPEAK
        </TransportButton>
      )}

      <TransportButton onClick={onPause} disabled={!speaking} label="Pause (P)">
        <Pause className="h-4 w-4" /> PAUSE
      </TransportButton>

      <TransportButton onClick={onStop} disabled={status === 'idle'} label="Stop (Escape)">
        <Square className="h-4 w-4" /> STOP
      </TransportButton>

      <TransportButton onClick={onFavorite} disabled={disabled} label="Favorite (Ctrl/Cmd + D)">
        <Star className={`h-4 w-4 ${isFavorite ? 'fill-cyan-glow text-cyan-glow' : ''}`} />
        {isFavorite ? 'SAVED' : 'FAVORITE'}
      </TransportButton>

      <TransportButton onClick={onSave} disabled={disabled} label="Save to history (Ctrl/Cmd + S)">
        <Save className="h-4 w-4" /> SAVE
      </TransportButton>
    </div>
  )
}
