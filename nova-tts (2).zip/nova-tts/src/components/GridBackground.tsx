export default function GridBackground() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-20 overflow-hidden bg-void-900">
      {/* Radial glow accents */}
      <div className="absolute -left-40 -top-40 h-[500px] w-[500px] rounded-full bg-blue-glow/10 blur-[120px]" />
      <div className="absolute -bottom-40 -right-40 h-[500px] w-[500px] rounded-full bg-cyan-glow/10 blur-[120px]" />

      {/* Moving grid */}
      <div
        className="absolute inset-0 opacity-[0.18] animate-grid-pan"
        style={{
          backgroundImage:
            'linear-gradient(rgba(0,229,255,0.35) 1px, transparent 1px), linear-gradient(90deg, rgba(0,229,255,0.35) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
      />

      {/* Vignette */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse at center, transparent 40%, rgba(3,5,10,0.9) 100%)',
        }}
      />
    </div>
  )
}
