export interface HistoryEntry {
  id: string
  text: string
  timestamp: number
  favorite: boolean
  voiceName?: string
}

export type SpeechStatus = 'idle' | 'speaking' | 'paused' | 'error'

export interface SpeechSettings {
  rate: number
  pitch: number
  volume: number
  voiceURI: string | null
}
