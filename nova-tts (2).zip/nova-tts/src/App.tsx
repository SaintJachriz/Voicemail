import { useCallback, useEffect, useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { Gauge, Music2, Volume2 } from 'lucide-react'

import GridBackground from './components/GridBackground'
import ParticleField from './components/ParticleField'
import Header from './components/Header'
import HudCircle from './components/HudCircle'
import Equalizer from './components/Equalizer'
import TextEditor from './components/TextEditor'
import ControlSlider from './components/ControlSlider'
import VoiceSelector from './components/VoiceSelector'
import TransportControls from './components/TransportControls'
import HistoryPanel from './components/HistoryPanel'
import SystemStats from './components/SystemStats'
import GlassPanel from './components/GlassPanel'
import TeleprompterView from './components/TeleprompterView'

import { useSpeech } from './hooks/useSpeech'
import { useLocalStorage } from './hooks/useLocalStorage'
import type { HistoryEntry } from './types'

const GREETING = 'Hello, I am your AI assistant. Systems online and ready.'

export default function App() {
  const [text, setText] = useState('')
  const [rate, setRate] = useLocalStorage('nova:rate', 1)
  const [pitch, setPitch] = useLocalStorage('nova:pitch', 1)
  const [volume, setVolume] = useLocalStorage('nova:volume', 1)
  const [voiceURI, setVoiceURI] = useLocalStorage<string | null>('nova:voice', null)
  const [history, setHistory] = useLocalStorage<HistoryEntry[]>('nova:history', [])
  const [hasGreeted, setHasGreeted] = useLocalStorage('nova:greeted', false)

  const {
    voices,
    status,
    error,
    level,
    boundary,
    sentences,
    currentSentenceIndex,
    supported,
    speak,
    pause,
    resume,
    stop,
  } = useSpeech({
    rate,
    pitch,
    volume,
    voiceURI,
  })

  // Pick a sensible default voice once the list loads
  useEffect(() => {
    if (voices.length && !voiceURI) {
      const preferred = voices.find((v) => v.default) ?? voices[0]
      setVoiceURI(preferred.voiceURI)
    }
  }, [voices, voiceURI, setVoiceURI])

  // One-time greeting on first ever visit
  useEffect(() => {
    if (!supported || hasGreeted || !voices.length) return
    const id = window.setTimeout(() => {
      speak(GREETING)
      setHasGreeted(true)
    }, 900)
    return () => window.clearTimeout(id)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [supported, hasGreeted, voices.length])

  const currentVoiceName = useMemo(
    () => voices.find((v) => v.voiceURI === voiceURI)?.name,
    [voices, voiceURI],
  )

  const isFavorite = useMemo(() => {
    const trimmed = text.trim()
    if (!trimmed) return false
    return history.some((h) => h.text === trimmed && h.favorite)
  }, [history, text])

  const handlePlay = useCallback(() => speak(text), [speak, text])

  const handleSave = useCallback(() => {
    const trimmed = text.trim()
    if (!trimmed) return
    setHistory((prev) => [
      { id: crypto.randomUUID(), text: trimmed, timestamp: Date.now(), favorite: false, voiceName: currentVoiceName },
      ...prev,
    ].slice(0, 100))
  }, [text, currentVoiceName, setHistory])

  const handleFavorite = useCallback(() => {
    const trimmed = text.trim()
    if (!trimmed) return
    setHistory((prev) => {
      const existing = prev.find((h) => h.text === trimmed)
      if (existing) {
        return prev.map((h) => (h.text === trimmed ? { ...h, favorite: !h.favorite } : h))
      }
      return [
        { id: crypto.randomUUID(), text: trimmed, timestamp: Date.now(), favorite: true, voiceName: currentVoiceName },
        ...prev,
      ].slice(0, 100)
    })
  }, [text, currentVoiceName, setHistory])

  const handleLoadEntry = useCallback((entry: HistoryEntry) => setText(entry.text), [])
  const handleToggleFavoriteById = useCallback(
    (id: string) => setHistory((prev) => prev.map((h) => (h.id === id ? { ...h, favorite: !h.favorite } : h))),
    [setHistory],
  )
  const handleDeleteEntry = useCallback(
    (id: string) => setHistory((prev) => prev.filter((h) => h.id !== id)),
    [setHistory],
  )

  // Global keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement
      const isTyping = target.tagName === 'TEXTAREA' || target.tagName === 'INPUT'

      if (e.code === 'Space' && !isTyping) {
        e.preventDefault()
        if (status === 'paused') resume()
        else if (status !== 'speaking') speak(text)
      } else if ((e.key === 'p' || e.key === 'P') && !isTyping) {
        pause()
      } else if (e.key === 'Escape') {
        stop()
      } else if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 's') {
        e.preventDefault()
        handleSave()
      } else if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'd') {
        e.preventDefault()
        handleFavorite()
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [status, text, speak, pause, resume, stop, handleSave, handleFavorite])

  return (
    <div className="relative min-h-screen">
      <GridBackground />
      <ParticleField />

      <main className="relative z-10 mx-auto flex max-w-6xl flex-col px-4 pb-16 sm:px-6 lg:px-8">
        <Header status={status} />

        <HudCircle status={status} level={level} />

        <div className="mt-4 space-y-4">
          <Equalizer status={status} level={level} />
          {(status === 'speaking' || status === 'paused') && sentences.length > 0 && (
            <TeleprompterView
              sentences={sentences}
              currentSentenceIndex={currentSentenceIndex}
              boundary={boundary}
              status={status}
            />
          )}
        </div>

        {!supported && (
          <div className="mt-4 rounded-lg border border-red-400/30 bg-red-400/5 p-3 text-center font-mono text-xs text-red-300">
            Speech synthesis is not supported in this browser.
          </div>
        )}
        {error && (
          <div className="mt-4 rounded-lg border border-red-400/30 bg-red-400/5 p-3 text-center font-mono text-xs text-red-300">
            {error}
          </div>
        )}

        <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-[2fr_1fr]">
          {/* Left column: editor + controls */}
          <div className="space-y-6">
            <TextEditor value={text} onChange={setText} />

            <GlassPanel delay={0.15} className="p-5 sm:p-6">
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <VoiceSelector voices={voices} voiceURI={voiceURI} onChange={setVoiceURI} />
                </div>
                <ControlSlider
                  label="SPEED"
                  icon={Gauge}
                  value={rate}
                  min={0.5}
                  max={2}
                  step={0.05}
                  onChange={setRate}
                  formatValue={(v) => `${v.toFixed(2)}x`}
                />
                <ControlSlider
                  label="PITCH"
                  icon={Music2}
                  value={pitch}
                  min={0}
                  max={2}
                  step={0.05}
                  onChange={setPitch}
                />
                <ControlSlider
                  label="VOLUME"
                  icon={Volume2}
                  value={volume}
                  min={0}
                  max={1}
                  step={0.05}
                  onChange={setVolume}
                  formatValue={(v) => `${Math.round(v * 100)}%`}
                />
              </div>

              <div className="mt-6 border-t border-white/5 pt-5">
                <TransportControls
                  status={status}
                  disabled={!supported || !text.trim()}
                  onPlay={handlePlay}
                  onPause={pause}
                  onResume={resume}
                  onStop={stop}
                  onFavorite={handleFavorite}
                  onSave={handleSave}
                  isFavorite={isFavorite}
                />
              </div>
            </GlassPanel>

            <p className="text-center font-mono text-[10px] tracking-wider text-white/25">
              SPACE speak/resume &middot; P pause &middot; ESC stop &middot; ⌘/CTRL+S save &middot; ⌘/CTRL+D
              favorite
            </p>
          </div>

          {/* Right column: system panels */}
          <div className="space-y-6">
            <SystemStats />
            <GlassPanel delay={0.4} className="p-5 sm:p-6">
              <p className="mb-3 font-mono text-[10px] tracking-[0.3em] text-white/40">
                HISTORY &amp; FAVORITES
              </p>
              <HistoryPanel
                history={history}
                onLoad={handleLoadEntry}
                onToggleFavorite={handleToggleFavoriteById}
                onDelete={handleDeleteEntry}
              />
            </GlassPanel>
          </div>
        </div>

        <motion.footer
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-12 text-center font-mono text-[10px] tracking-widest text-white/20"
        >
          NOVA RUNS ENTIRELY IN YOUR BROWSER — NO AUDIO OR TEXT LEAVES YOUR DEVICE
        </motion.footer>
      </main>
    </div>
  )
}
