import { useCallback, useEffect, useRef, useState } from 'react'
import type { SpeechStatus } from '../types'

interface UseSpeechArgs {
  rate: number
  pitch: number
  volume: number
  voiceURI: string | null
}

export interface SpeechBoundary {
  charIndex: number
  charLength: number
}

/**
 * Splits text into sentences. Prefers Intl.Segmenter (accurate, locale-aware)
 * and falls back to a punctuation-based regex for older environments.
 */
function splitIntoSentences(text: string): string[] {
  const IntlAny = Intl as unknown as {
    Segmenter?: new (
      locale: string | undefined,
      opts: { granularity: 'sentence' },
    ) => { segment: (t: string) => Iterable<{ segment: string }> }
  }

  if (IntlAny.Segmenter) {
    try {
      const segmenter = new IntlAny.Segmenter(undefined, { granularity: 'sentence' })
      const parts = Array.from(segmenter.segment(text), (s) => s.segment.trim()).filter(Boolean)
      if (parts.length) return parts
    } catch {
      // fall through to regex fallback
    }
  }

  const matches = text.match(/[^.!?]+[.!?]+(?:\s+|$)|[^.!?]+$/g) || [text]
  return matches.map((s) => s.trim()).filter(Boolean)
}

/** Natural pause length (ms) based on how the sentence ends. */
function pauseDurationFor(sentence: string): number {
  const last = sentence.trim().slice(-1)
  if (last === '.' || last === '!' || last === '?') return 420
  if (last === ',' || last === ';' || last === ':') return 200
  return 260
}

export function useSpeech({ rate, pitch, volume, voiceURI }: UseSpeechArgs) {
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([])
  const [status, setStatus] = useState<SpeechStatus>('idle')
  const [error, setError] = useState<string | null>(null)
  const [level, setLevel] = useState(0) // 0..1 amplitude proxy for visualizer
  const [boundary, setBoundary] = useState<SpeechBoundary | null>(null)
  const [sentences, setSentences] = useState<string[]>([])
  const [currentSentenceIndex, setCurrentSentenceIndex] = useState(-1)

  const levelTimerRef = useRef<number | null>(null)
  const gapTimeoutRef = useRef<number | null>(null)
  const gapPausedRef = useRef(false)
  const sessionIdRef = useRef(0)
  const sentencesRef = useRef<string[]>([])
  const argsRef = useRef({ rate, pitch, volume, voiceURI, voices })
  argsRef.current = { rate, pitch, volume, voiceURI, voices }

  const supported = typeof window !== 'undefined' && 'speechSynthesis' in window

  useEffect(() => {
    if (!supported) return

    const loadVoices = () => {
      const list = window.speechSynthesis.getVoices()
      if (list.length) setVoices(list)
    }

    loadVoices()
    window.speechSynthesis.onvoiceschanged = loadVoices

    return () => {
      window.speechSynthesis.onvoiceschanged = null
    }
  }, [supported])

  const stopLevelAnimation = useCallback(() => {
    if (levelTimerRef.current) {
      window.clearInterval(levelTimerRef.current)
      levelTimerRef.current = null
    }
    setLevel(0)
  }, [])

  const startLevelAnimation = useCallback(() => {
    stopLevelAnimation()
    levelTimerRef.current = window.setInterval(() => {
      setLevel(Math.random() * 0.85 + 0.15)
    }, 90)
  }, [stopLevelAnimation])

  const clearGap = useCallback(() => {
    if (gapTimeoutRef.current) {
      window.clearTimeout(gapTimeoutRef.current)
      gapTimeoutRef.current = null
    }
  }, [])

  const playSentenceAt = useCallback(
    (index: number, session: number) => {
      if (session !== sessionIdRef.current) return // stale call from a previous speak()/stop()

      const list = sentencesRef.current
      if (index >= list.length) {
        setStatus('idle')
        stopLevelAnimation()
        setBoundary(null)
        setCurrentSentenceIndex(list.length)
        return
      }

      const sentence = list[index]
      if (!sentence) {
        playSentenceAt(index + 1, session)
        return
      }

      const { rate, pitch, volume, voiceURI, voices } = argsRef.current
      const utter = new SpeechSynthesisUtterance(sentence)
      const chosenVoice = voices.find((v) => v.voiceURI === voiceURI)
      if (chosenVoice) utter.voice = chosenVoice
      utter.rate = rate
      utter.pitch = pitch
      utter.volume = volume

      utter.onstart = () => {
        if (session !== sessionIdRef.current) return
        setStatus('speaking')
        setCurrentSentenceIndex(index)
        startLevelAnimation()
      }

      utter.onboundary = (e) => {
        if (session !== sessionIdRef.current) return
        if (e.name === 'word' || e.name === 'sentence' || !e.name) {
          setBoundary({ charIndex: e.charIndex, charLength: e.charLength || 0 })
        }
      }

      utter.onend = () => {
        if (session !== sessionIdRef.current) return
        stopLevelAnimation()
        setBoundary(null)

        const next = index + 1
        if (next >= list.length) {
          setStatus('idle')
          setCurrentSentenceIndex(list.length)
          return
        }

        const delay = pauseDurationFor(sentence)
        gapTimeoutRef.current = window.setTimeout(() => {
          gapTimeoutRef.current = null
          if (session === sessionIdRef.current && !gapPausedRef.current) {
            playSentenceAt(next, session)
          }
        }, delay)
      }

      utter.onerror = (e) => {
        if (session !== sessionIdRef.current) return
        // "interrupted"/"canceled" are expected when we intentionally cancel to
        // move to the next sentence or stop — not real errors worth surfacing.
        if (e.error !== 'interrupted' && e.error !== 'canceled') {
          setError(e.error || 'Playback error')
          setStatus('error')
        }
        stopLevelAnimation()
        setBoundary(null)
      }

      utter.onpause = () => {
        if (session !== sessionIdRef.current) return
        setStatus('paused')
        stopLevelAnimation()
      }

      utter.onresume = () => {
        if (session !== sessionIdRef.current) return
        setStatus('speaking')
        startLevelAnimation()
      }

      window.speechSynthesis.speak(utter)
    },
    [startLevelAnimation, stopLevelAnimation],
  )

  const speak = useCallback(
    (text: string) => {
      if (!supported) {
        setError('Speech synthesis is not supported in this browser.')
        setStatus('error')
        return
      }
      const trimmed = text.trim()
      if (!trimmed) return

      window.speechSynthesis.cancel()
      clearGap()
      gapPausedRef.current = false
      sessionIdRef.current += 1
      const session = sessionIdRef.current

      const split = splitIntoSentences(trimmed)
      sentencesRef.current = split
      setSentences(split)
      setCurrentSentenceIndex(0)
      setError(null)
      setBoundary(null)

      playSentenceAt(0, session)
    },
    [supported, clearGap, playSentenceAt],
  )

  const pause = useCallback(() => {
    if (!supported) return
    if (window.speechSynthesis.speaking && !window.speechSynthesis.paused) {
      window.speechSynthesis.pause()
    } else if (gapTimeoutRef.current) {
      // We're in the natural pause between sentences — freeze there.
      clearGap()
      gapPausedRef.current = true
      setStatus('paused')
    }
  }, [supported, clearGap])

  const resume = useCallback(() => {
    if (!supported) return
    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume()
    } else if (gapPausedRef.current) {
      gapPausedRef.current = false
      setStatus('speaking')
      playSentenceAt(currentSentenceIndex + 1, sessionIdRef.current)
    }
  }, [supported, currentSentenceIndex, playSentenceAt])

  const stop = useCallback(() => {
    if (!supported) return
    sessionIdRef.current += 1 // invalidate any in-flight callbacks/timeouts
    clearGap()
    gapPausedRef.current = false
    window.speechSynthesis.cancel()
    setStatus('idle')
    stopLevelAnimation()
    setBoundary(null)
    setCurrentSentenceIndex(-1)
  }, [supported, clearGap, stopLevelAnimation])

  useEffect(() => {
    return () => {
      sessionIdRef.current += 1
      clearGap()
      stopLevelAnimation()
      if (supported) window.speechSynthesis.cancel()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return {
    voices,
    status,
    error,
    level,
    boundary,
    sentences,
    currentSentenceIndex,
    supported,
    speak,
    pause,
    resume,
    stop,
  }
}
