// Parses uploaded documents into plain text for the speech engine.
// Supported: .txt, .md (read as-is), .docx (via mammoth), .pdf (via pdfjs-dist)

export const ACCEPTED_EXTENSIONS = ['.txt', '.md', '.docx', '.pdf'] as const
export const ACCEPTED_MIME_HINT =
  '.txt,.md,.docx,.pdf,text/plain,text/markdown,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document'

export class UnsupportedFileError extends Error {
  constructor(filename: string) {
    super(`"${filename}" isn't a supported file type. Try .txt, .md, .docx, or .pdf.`)
    this.name = 'UnsupportedFileError'
  }
}

function getExtension(filename: string): string {
  const idx = filename.lastIndexOf('.')
  return idx === -1 ? '' : filename.slice(idx).toLowerCase()
}

async function parsePlainText(file: File): Promise<string> {
  return file.text()
}

async function parseDocx(file: File): Promise<string> {
  const mammoth = await import('mammoth')
  const arrayBuffer = await file.arrayBuffer()
  const result = await mammoth.extractRawText({ arrayBuffer })
  return result.value
}

async function parsePdf(file: File): Promise<string> {
  const pdfjsLib = await import('pdfjs-dist')
  // Vite-friendly worker setup: bundle the worker as a URL asset.
  const workerUrl = (await import('pdfjs-dist/build/pdf.worker.min.mjs?url')).default
  pdfjsLib.GlobalWorkerOptions.workerSrc = workerUrl

  const arrayBuffer = await file.arrayBuffer()
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise

  const pageTexts: string[] = []
  for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
    const page = await pdf.getPage(pageNum)
    const content = await page.getTextContent()
    const text = content.items
      .map((item) => ('str' in item ? item.str : ''))
      .join(' ')
    pageTexts.push(text)
  }
  return pageTexts.join('\n\n')
}

/**
 * Reads a File and returns its extracted plain text content.
 * Throws UnsupportedFileError for unrecognized extensions.
 */
export async function parseDocumentFile(file: File): Promise<string> {
  const ext = getExtension(file.name)

  switch (ext) {
    case '.txt':
    case '.md':
      return normalizeWhitespace(await parsePlainText(file))
    case '.docx':
      return normalizeWhitespace(await parseDocx(file))
    case '.pdf':
      return normalizeWhitespace(await parsePdf(file))
    default:
      throw new UnsupportedFileError(file.name)
  }
}

function normalizeWhitespace(text: string): string {
  return text
    .replace(/\r\n/g, '\n')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
}
